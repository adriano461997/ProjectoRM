<?php

namespace App\Http\Controllers;

use App\Models\Insights1;
use Illuminate\Http\Request;

class Insights1Controller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Insights1 $insights1)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Insights1 $insights1)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Insights1 $insights1)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Insights1 $insights1)
    {
        //
    }
}
