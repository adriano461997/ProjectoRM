<?php

namespace App\Http\Controllers;

class HomeFiliarController extends Controller
{
    public function index()
    {

    }
}
