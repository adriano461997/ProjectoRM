// @flow
import * as React from 'react';
import {
    SidebarGroup,
    SidebarGroupLabel,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem
} from "@/components/ui/sidebar";
import {Link, usePage} from "@inertiajs/react";
import {ArrowRight, ChartBar, Home, LayoutPanelTop, ListIcon, Users} from "lucide-react";

type Props = {

};

export const NavAdmin = () => {
    const {props} = usePage();
    return (
        <>
            <SidebarGroup>
                <SidebarGroupLabel>Home</SidebarGroupLabel>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton asChild isActive={route().current("dashboard")}>
                            <Link href={"/"}>
                                <Home /> Dashboard
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                        <SidebarMenuButton asChild isActive={route().current("empresas.index")}>
                            <Link href={route("empresas.index")}>
                                <LayoutPanelTop /> Empresas
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>

                    <SidebarMenuItem>
                        <SidebarMenuButton asChild isActive={route().current("categorias.index")}>
                            <Link href={route("categorias.index")}>
                                <ListIcon /> Categorias
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>

                    <SidebarMenuItem>
                        <SidebarMenuButton asChild isActive={route().current("usuarios.index")}>
                            <Link href={route("usuarios.index")}>
                                <Users /> Usuários
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>


                    <SidebarMenuItem>
                        <SidebarMenuButton asChild>
                            <Link href={route("escolher")}>
                                <ArrowRight /> Escolher
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>

                </SidebarMenu>
            </SidebarGroup>

            <SidebarGroup>
                <SidebarGroupLabel>Resumo</SidebarGroupLabel>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton asChild isActive={route().current("recuso.index")}>
                            <Link href={route("resumo.index")}>
                                <ChartBar /> Resumo
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>
            </SidebarGroup>

            <SidebarGroup>
                <SidebarGroupLabel>Relatórios</SidebarGroupLabel>

                {
                    props.categorias.map((item)=>(
                        <SidebarMenuItem key={item.id}>
                            <SidebarMenuButton title={item.nome} className={"truncate"} asChild isActive={route().current("relatorio.index", [item.slug])}>
                                <Link href={route("relatorio.index", [item.slug])}>
                                    <ListIcon /> {item.nome}
                                </Link>
                            </SidebarMenuButton>
                        </SidebarMenuItem>
                    ))
                }

            </SidebarGroup>
        </>
    );
};
