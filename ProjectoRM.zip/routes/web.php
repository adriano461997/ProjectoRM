<?php
use App\Http\Controllers\CategoriasController;
use App\Http\Controllers\EmpresasController;
use App\Http\Controllers\FiliarCategoriaController;
use App\Http\Controllers\FiliarController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\InsiController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RelatorioController;
use App\Http\Controllers\ResumoController;
use App\Http\Controllers\UsuariosController;
use App\Http\Middleware\CheckFiliarMiddleware;
use App\Http\Middleware\ShareFiliarPropsMiddleware;
use Illuminate\Support\Facades\Route;


Route::middleware('auth')->group(function () {

    Route::get("/escolher", [IndexController::class, "escolher"])->name("escolher");

    Route::prefix("/f/{slug}")->middleware([CheckFiliarMiddleware::class, ShareFiliarPropsMiddleware::class])->group(function (){
        Route::get("/", [FiliarController::class, "index"])->name("filiar.index");
        Route::prefix("/c/{c_slug}")->group(function (){
            Route::get("/", [FiliarCategoriaController::class, "index"])->name("filiar.categoria.index");
            Route::get("/adicionar", [FiliarCategoriaController::class, "create"])->name("filiar.categoria.add");
            Route::post("/adicionar", [FiliarCategoriaController::class, "store"])->name("filiar.categoria.add_post");
            Route::get("/{cat_id}/editar", [FiliarCategoriaController::class, "edit"])->name("filiar.categoria.editar");
            Route::post("/{cat_id}/editar", [FiliarCategoriaController::class, "update"])->name("filiar.categoria.editar_post");
            Route::post("/{cat_id}/eliminar", [FiliarCategoriaController::class, "destroy"])->name("filiar.categoria.eliminar");
        });
    });

    Route::get('/', [IndexController::class, "index"])->name("dashboard");
    Route::get('/insights/{slug}', [InsiController::class, "index"])->name("insi");

    Route::prefix("/relatorio/{slug}")->group(function(){
        Route::get("/", [RelatorioController::class, "index"])->name("relatorio.index");
    });

    Route::prefix("/resumo")->group(function(){
        Route::get("/", [ResumoController::class, "index"])->name("resumo.index");
    });

    Route::prefix("categorias")->group(function(){
        Route::get('/', [CategoriasController::class, "index"])->name("categorias.index");
        Route::get('/adicionar', [CategoriasController::class, "create"])->name("categorias.add");
        Route::post('/adicionar', [CategoriasController::class, "store"])->name("categorias.add_post");
        Route::get('/{cat_id}/editar', [CategoriasController::class, "edit"])->name("categorias.editar");
        Route::post('/{cat_id}/editar', [CategoriasController::class, "update"])->name("categorias.editar_post");
        Route::post('/{cat_id}/eliminar', [CategoriasController::class, "destroy"])->name("categorias.eliminar");
    });

    Route::prefix("empresas")->group(function(){
        Route::get('/', [EmpresasController::class, "index"])->name("empresas.index");
        Route::get('/adicionar', [EmpresasController::class, "create"])->name("empresas.add");
        Route::post('/adicionar', [EmpresasController::class, "store"])->name("empresas.add_post");
        Route::get('/{empresa_id}/editar', [EmpresasController::class, "edit"])->name("empresas.editar");
        Route::post('/{empresa_id}/editar', [EmpresasController::class, "update"])->name("empresas.editar_post");
        Route::post('/{empresa_id}/eliminar', [EmpresasController::class, "destroy"])->name("empresas.eliminar");
    });

    Route::prefix("usuarios")->group(function(){
        Route::get('/', [UsuariosController::class, "index"])->name("usuarios.index");
        Route::get('/adicionar', [UsuariosController::class, "create"])->name("usuarios.add");
        Route::post('/adicionar', [UsuariosController::class, "store"])->name("usuarios.add_post");
        Route::get('/{usuario_id}/editar', [UsuariosController::class, "edit"])->name("usuarios.editar");
        Route::post('/{usuario_id}/editar', [UsuariosController::class, "update"])->name("usuarios.editar_post");
        Route::post('/{usuario_id}/eliminar', [UsuariosController::class, "destroy"])->name("usuarios.eliminar");
    });

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
